/* Public client config only. Never add service_role or Discord client secret here. */
window.MIXTON_AUTH = { url: 'https://aqafdzspwevjedylhtyy.supabase.co', key: 'sb_publishable_Dact2ufG_naG6P-Kw8VO4A_3azQl2ti' };
