package com.mixton.music;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import org.json.JSONObject;
public class MainActivity extends Activity {
 private static final int FILE_CHOOSER_REQUEST=41;
 private WebView webView; private ValueCallback<Uri[]> filePathCallback; private String pendingAuthUrl;
 @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);
 getWindow().setStatusBarColor(Color.rgb(8,11,10));getWindow().setNavigationBarColor(Color.rgb(8,11,10));
 webView=new WebView(this);webView.setBackgroundColor(Color.rgb(8,11,10));WebSettings s=webView.getSettings();
 s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(true);s.setAllowContentAccess(true);
 webView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){super.onPageFinished(view,url);if(pendingAuthUrl!=null){String ready=pendingAuthUrl;pendingAuthUrl=null;deliverAuth(ready);}}@Override public boolean shouldOverrideUrlLoading(WebView view,String url){if(url!=null&&url.startsWith("mixton://auth")){deliverAuth(url);return true;}return false;}@Override public boolean shouldOverrideUrlLoading(WebView view,android.webkit.WebResourceRequest request){String url=request.getUrl().toString();if(url.startsWith("mixton://auth")){deliverAuth(url);return true;}return false;}});
 webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){if(filePathCallback!=null)filePathCallback.onReceiveValue(null);filePathCallback=callback;Intent intent=params.createIntent();intent.addCategory(Intent.CATEGORY_OPENABLE);try{startActivityForResult(intent,FILE_CHOOSER_REQUEST);}catch(Exception ex){filePathCallback=null;return false;}return true;}});
 setContentView(webView);webView.loadUrl("file:///android_asset/index.html");if(getIntent()!=null&&getIntent().getData()!=null)pendingAuthUrl=getIntent().getData().toString();
 }
 private void deliverAuth(String url){if(webView==null){pendingAuthUrl=url;return;}try{String quoted=JSONObject.quote(url);webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('mixton-auth-callback',{detail:"+quoted+"}));",null);}catch(Exception e){pendingAuthUrl=url;}}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent!=null&&intent.getData()!=null)deliverAuth(intent.getData().toString());}
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST&&filePathCallback!=null){Uri[] results=WebChromeClient.FileChooserParams.parseResult(resultCode,data);filePathCallback.onReceiveValue(results);filePathCallback=null;}}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
