-- Run this in Supabase SQL Editor to enable a shared public link library.
create table if not exists public.public_tracks (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 url text not null,
 lyrics_lrc text,
 creator_id uuid not null references auth.users(id) on delete cascade,
 creator_name text,
 created_at timestamptz not null default now()
);
alter table public.public_tracks enable row level security;
drop policy if exists "Anyone can read public tracks" on public.public_tracks;
create policy "Anyone can read public tracks" on public.public_tracks for select using (true);
drop policy if exists "Signed-in users can publish tracks" on public.public_tracks;
create policy "Signed-in users can publish tracks" on public.public_tracks for insert to authenticated with check (auth.uid() = creator_id);
