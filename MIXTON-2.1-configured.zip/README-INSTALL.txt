MIXTON 2.1 source project

New: MIXTON logo and launcher icon; public community library for YouTube URLs and direct audio stream URLs; optional LRC lyrics can be shared; Discord OAuth deep-link callback and Discord profile name/avatar display.

IMPORTANT LIMITS
- YouTube uses the official embedded player. MIXTON does not rip, download, or extract audio from YouTube.
- External direct audio URLs are streamed from their original host; the host must allow public access and playback.
- Shared public library stores links and optional lyrics, not copies of music files. Only share material you have permission to share.
- Lyrics are optional. If not provided, users can still play the track; a user may add LRC lyrics.

SET UP SHARED LIBRARY + DISCORD
1. Create a Supabase project. In Authentication > Providers, enable Discord and enter your Discord OAuth Client ID and Client Secret. Keep the Discord secret only in Supabase.
2. In Supabase Authentication URL configuration, add mixton://auth as an allowed redirect URL.
3. Run SUPABASE-PUBLIC-LIBRARY.sql in Supabase SQL Editor.
4. Put the Supabase Project URL and public anon/publishable key in app/src/main/assets/config.js. Never use service_role key.
5. In Discord Developer Portal, set the OAuth redirect URL to the Supabase callback URL shown in the Discord provider settings in Supabase (not mixton://auth).
6. Rebuild and install the APK. Test Discord login on a real device.

The public library is readable by all users once configured. Publishing requires Discord sign-in.
